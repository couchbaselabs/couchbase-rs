/* API3 is now the main API. refer to couchbase.h */
#include <libcouchbase/couchbase.h>
